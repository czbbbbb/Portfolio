﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace PetAdoptionCenter;

public partial class MainWindow : Window
{
    private AdoptionCenter _adoptionCenter = new AdoptionCenter();

    public MainWindow()
    {
        InitializeComponent();
        LoadAnimalsFromFile("Resources/animals.txt");
        AnimalListView.ItemsSource = _adoptionCenter.ListAvailableAnimals();
    }

    private void LoadAnimalsFromFile(string filePath)
    {
        if (!File.Exists(filePath)) return;
        var lines = File.ReadAllLines(filePath);
        foreach (var line in lines)
        {
            var parts = line.Split(',');
            if (parts[0] == "Dog")
                _adoptionCenter.AddAnimal(new Dog(parts[1], int.Parse(parts[2]), parts[3]));
            else if (parts[0] == "Cat")
                _adoptionCenter.AddAnimal(new Cat(parts[1], int.Parse(parts[2]), parts[3]));
        }
    }

    private void AdoptButton_Click(object sender, RoutedEventArgs e)
    {
        var name = AdoptNameTextBox.Text;
        var result = _adoptionCenter.AdoptAnimal(name);
        StatusTextBlock.Text = result;
        AnimalListView.ItemsSource = null;
        AnimalListView.ItemsSource = _adoptionCenter.ListAvailableAnimals();
    }

    private void AddButton_Click(object sender, RoutedEventArgs e)
    {
        var name = NewNameTextBox.Text;
        var age = int.Parse(NewAgeTextBox.Text);
        var type = TypeComboBox.Text;
        var breed = BreedTextBox.Text;

        if (type == "Dog")
            _adoptionCenter.AddAnimal(new Dog(name, age, breed));
        else if (type == "Cat")
            _adoptionCenter.AddAnimal(new Cat(name, age, breed));

        AnimalListView.ItemsSource = null;
        AnimalListView.ItemsSource = _adoptionCenter.ListAvailableAnimals();
    }
}

public abstract class Animal
{
    public string Name { get; set; }
    public string Type => GetType().Name;
    public int Age { get; set; }
    public bool IsAdopted { get; set; }

    public Animal(string name, int age)
    {
        Name = name;
        Age = age;
        IsAdopted = false;
    }

    public abstract string MakeSound();
}

public class Dog : Animal
{
    public string Breed { get; set; }

    public Dog(string name, int age, string breed) : base(name, age)
    {
        Breed = breed;
    }

    public override string MakeSound() => "Woof!";
}

public class Cat : Animal
{
    public string Breed { get; set; }

    public Cat(string name, int age, string breed) : base(name, age)
    {
        Breed = breed;
    }

    public override string MakeSound() => "Meow!";
}

public class AdoptionCenter
{
    private List<Animal> _animals = new List<Animal>();

    public void AddAnimal(Animal animal) => _animals.Add(animal);
    public void AddAnimal(string type, string name, int age, string breed)
    {
        if (type == "Dog") AddAnimal(new Dog(name, age, breed));
        else if (type == "Cat") AddAnimal(new Cat(name, age, breed));
    }

    public string AdoptAnimal(string name)
    {
        var animal = _animals.Find(a => a.Name == name);
        if (animal == null) return "Animal not found.";
        if (animal.IsAdopted) return "Already adopted.";

        animal.IsAdopted = true;
        Logger.Log($"{animal.Name} adopted.");
        return $"{animal.Name} has been adopted!";
    }

    public List<Animal> ListAvailableAnimals() => _animals.FindAll(a => !a.IsAdopted);
}

public static class Logger
{
    public static void Log(string message)
    {
        File.AppendAllText("Resources/log.txt", $"{DateTime.Now}: {message}\n");
    }
}
