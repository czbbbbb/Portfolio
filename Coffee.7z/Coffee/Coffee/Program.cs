﻿/*
 * Coffee Simulation (Event Handlers)
 * Dinh An Nguyen
 * 3/10/25
 * Modified and extended from example code at http://www.albahari.com/nutshell/E9-CH04.aspx
 */

using Coffee;
using System;

namespace Coffee
{
    class Program
    {
        static void Main()
        {
            Console.Title = "Programming II Coffee Simulation (Event Handlers) by Dinh An Nguen";
            Simulation sim = new Simulation();
            sim.SetUp();
        }
    }
}