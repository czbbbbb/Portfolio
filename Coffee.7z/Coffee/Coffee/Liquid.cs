﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coffee
{
    public enum Size
    {
        Tiny = 4,
        Small = 8,
        Medium = 12,
        Large = 16,
        Collosal = 20
    }

    public enum LiquidStartingTemperature
    {
        Hot,
        Cold,
        Neutral
    }

    public enum BeverageType
    {
        Coffee,
        Tea,
        Water
    }


    public class Liquid
    {
        private decimal temperature = 171;
        private string name = "coffee";
        private Size beverageSize = Size.Small; // default size
        private LiquidStartingTemperature initialTempState = LiquidStartingTemperature.Hot; // default state

        public string Name { get => name; set => name = value; }
        public Size BeverageSize { get => beverageSize; set => beverageSize = value; }
        public LiquidStartingTemperature InitialTempState { get => initialTempState; set => initialTempState = value; }

        public bool Hot => temperature > 100;
        public event EventHandler<TemperatureChangedEventArgs> TemperatureChanged;

        protected virtual void OnTemperatureChanged(TemperatureChangedEventArgs e)
        {
            TemperatureChanged?.Invoke(this, e);
        }

        public decimal Temperature
        {
            get => temperature;
            set
            {
                if (temperature == value) return;
                decimal oldTemp = temperature;
                temperature = value;
                OnTemperatureChanged(new TemperatureChangedEventArgs(oldTemp, temperature));
            }
        }

        public void temperature_ValueChanged(object sender, TemperatureChangedEventArgs e)
        {
            if ((e.NewTemperature != e.LastTemperature))
                Console.WriteLine($"Alert: temperature has changed for {name} from {e.LastTemperature} to {e.NewTemperature} (a difference of {(e.NewTemperature - e.LastTemperature)}).");
        }

        public class TemperatureChangedEventArgs : EventArgs
        {
            public readonly decimal LastTemperature;
            public readonly decimal NewTemperature;

            public TemperatureChangedEventArgs(decimal lastTemp, decimal newTemp)
            {
                LastTemperature = lastTemp;
                NewTemperature = newTemp;
            }
        }

        public string About()
        {
            return $"{name} ({beverageSize}) has a temperature of {temperature} and started as {initialTempState}";
        }
    }
}