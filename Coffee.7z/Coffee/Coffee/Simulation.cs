﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Coffee;

namespace Coffee
{
    class Simulation
    {
        Liquid l = new Liquid();
        decimal initialTemperature = 0m; //get the liquid's starting temperature
        decimal ambientTemperature = 75.0m; //room temperature
        decimal coolingRate = 0.1m;
        decimal time = 0m;
        string timeType = "second";
        string measurementUnit = "degrees";

        public void SetUp()
        {
            initialTemperature = l.Temperature;
            Run();
        }

        private void Run()
        {
            time += 0.1m;
            if (timeType == "second")
            {
                if (time > 1) { timeType = timeType + "s"; }
            }

            if (time > 200)
            {
                Console.WriteLine($"over 200");
            }
            else
            {
                l.Temperature = Math.Floor(NewtonsLawCooling(l.Temperature, ambientTemperature, coolingRate, time));
                if (l.Temperature >= ambientTemperature)
                {
                    Console.WriteLine($"{l.Name} is {l.Temperature} {measurementUnit} after {time:F1} {timeType}.");
                    if (l.Temperature != ambientTemperature)
                        Run();
                }
                else
                {
                    Console.WriteLine($"{l.Name} is the same temperature as {ambientTemperature}.");
                }
            }
        }

        public decimal NewtonsLawCooling(decimal initialTemperature, decimal ambientTemperature, decimal coolingConstant, decimal time)
        {
            return Convert.ToDecimal(Convert.ToDouble(ambientTemperature + (initialTemperature - ambientTemperature)) * Math.Exp(Convert.ToDouble(-coolingConstant * time)));
        }
    }
}
