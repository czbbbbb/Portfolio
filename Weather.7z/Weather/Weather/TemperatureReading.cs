﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weather
{
    class TemperatureReading
    {
        public string WeatherDescription { get; set; } = "weather description unavailable";
        public float Temperature { get; set; } = 75.5f;

        public TemperatureReading(string description, float temperature)
        {
            WeatherDescription = description;
            Temperature = temperature;
        }
    }
}
