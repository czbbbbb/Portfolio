﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Weather
{
    class Utility
    {
        private static string APIKey = ConfigurationManager.AppSettings["OpenWeatherMapAPIKey"];
        private static string fileName =
            "http://api.openweathermap.org/data/2.5/weather?q=Chicago&mode=xml&units=imperial&APPID=" + APIKey;

        public static TemperatureReading CurrentTemperature()
        {
            string description = "Cloudy";
            string temperatureString = "60";
            float temperature = 0;

            XDocument xdoc = XDocument.Load(fileName);
            var tempList = xdoc.Descendants()
                          .Where(x => x.Name == "temperature" || x.Name == "weather");

            foreach (XElement node in tempList)
            {
                if (node.Name == "temperature")
                {
                    temperatureString = node.Attribute("value").Value;
                    float.TryParse(temperatureString, out temperature);
                }

                if (node.Name == "weather")
                {
                    description = node.Attribute("value").Value;
                }
            }

            return new TemperatureReading(description, temperature);
        }
    }
}
