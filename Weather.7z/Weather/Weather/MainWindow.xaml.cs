﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Weather;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private TemperatureReading currentTemperature;

    public MainWindow()
    {
        InitializeComponent();
        UpdateWeatherInformation();
    }

    private void UpdateWeatherInformation()
    {
        currentTemperature = Utility.CurrentTemperature();

        lblCity.Content = "Chicago";
        lblTemperature.Content = $"{currentTemperature.Temperature}°F";
        lblDescription.Content = currentTemperature.WeatherDescription;
        lblTime.Content = DateTime.Now.ToString("G");

        ShowWeatherGraphic();
        TemperatureIndicator.Fill = GetTemperatureIndicatorColor(currentTemperature.Temperature);
    }

    private void ShowWeatherGraphic()
    {
        string basePath = AppDomain.CurrentDomain.BaseDirectory + "../../media/";
        string description = currentTemperature.WeatherDescription.ToLower();

        if (description.Contains("sun"))
        {
            WeatherGraphic.Source = new BitmapImage(new Uri(basePath + "sun.png", UriKind.Absolute));
        }
        else if (description.Contains("cloud"))
        {
            WeatherGraphic.Source = new BitmapImage(new Uri(basePath + "clouds.png", UriKind.Absolute));
        }
        else if (description.Contains("rain"))
        {
            WeatherGraphic.Source = new BitmapImage(new Uri(basePath + "rain.png", UriKind.Absolute));
        }
        else if (description.Contains("snow"))
        {
            WeatherGraphic.Source = new BitmapImage(new Uri(basePath + "snow.png", UriKind.Absolute));
        }
        else
        {
            WeatherGraphic.Source = new BitmapImage(new Uri(basePath + "default.png", UriKind.Absolute));
        }
    }

    private Brush GetTemperatureIndicatorColor(float temperature)
    {
        if (temperature < 40)
            return new SolidColorBrush(Colors.Blue);
        else if (temperature < 60)
            return new SolidColorBrush(Colors.Teal);
        else if (temperature < 70)
            return new SolidColorBrush(Colors.Green);
        else if (temperature < 80)
            return new SolidColorBrush(Colors.Yellow);
        else if (temperature < 100)
            return new SolidColorBrush(Colors.Orange);
        else
            return new SolidColorBrush(Colors.Red);
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
        UpdateWeatherInformation();
    }
}