﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTwo
{
    public class Deck
    {
        private List<Card> cards;
        private Random rand = new Random();

        public Deck(int numSuits = 4)
        {
            cards = new List<Card>();
            for (int suit = 0; suit < numSuits; suit++)
            {
                for (int value = 2; value <= 14; value++)
                {
                    cards.Add(new Card(value, suit));
                }
            }
            Shuffle();
        }

        public void Shuffle()
        {
            for (int i = 0; i < cards.Count; i++)
            {
                int swapIndex = rand.Next(cards.Count);
                (cards[i], cards[swapIndex]) = (cards[swapIndex], cards[i]);
            }
        }

        public Card DrawCard()
        {
            if (cards.Count == 0)
                return null;
            Card drawnCard = cards[0];
            cards.RemoveAt(0);
            return drawnCard;
        }
    }

}
