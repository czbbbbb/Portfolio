﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectTwo;

/*
 * Project Two: Console Framework
 * Dinh An Nguyen
 * Credits
 * - Save and Load Feature from ChatGPT
 */

namespace ProjectTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            HandleSaveSelection(); 

            Menu menu = new Menu();
            IGame game = new GameLogic(); 

            while (true)
            {
                menu.ShowMainMenu();
                string choice = menu.GetUserChoice();

                switch (choice)
                {
                    case "1":
                        while (true)
                        {
                            Console.Clear();
                            Console.WriteLine("Choose a game to play:");
                            Console.WriteLine("1. Apples or Oranges 🍏🍊");
                            Console.WriteLine("2. Higher or Lower ⬆⬇");
                            Console.WriteLine("3. Highest Match 🎴");
                            Console.WriteLine("4. Return to Main Menu");
                            Console.Write("Enter the game number: ");
                            string gameChoice = Console.ReadLine();

                            if (gameChoice == "4") break;

                            string gameName = gameChoice switch
                            {
                                "1" => "Apples or Oranges",
                                "2" => "Higher or Lower",
                                "3" => "Highest Match",
                                _ => null
                            };

                            if (gameName != null)
                            {
                                game.PlayGame(gameName);
                                RecordKeeper.SaveRecords();
                            }
                            else
                            {
                                Console.WriteLine("Invalid selection. Press any key to try again.");
                                Console.ReadKey();
                            }
                        }
                        break;

                    case "2":
                        RecordKeeper.ShowRecords();
                        break;

                    case "3":
                        Console.WriteLine("Exiting...");
                        RecordKeeper.SaveRecords();
                        return;

                    default:
                        Console.WriteLine("Invalid option. Press any key to try again.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void HandleSaveSelection() // Let player choose to create/load a save file
        {
            while (true) // Keeps looping until the player selects a valid option or exits
            {
                Console.Clear();
                Console.WriteLine("========== Project Two Game Collection ==========");
                Console.WriteLine("1. Create New Save");
                Console.WriteLine("2. Load Save");
                Console.WriteLine("3. Return to Main Menu");
                Console.Write("Enter choice: ");
                string choice = Console.ReadLine();

                if (choice == "1") // Create New Save
                {
                    CreateNewSaveFile();
                }
                else if (choice == "2") // Load Save
                {
                    List<string> saveFiles = RecordKeeper.GetSaveFiles();

                    if (saveFiles.Count == 0)
                    {
                        Console.WriteLine("No save files found. Creating a new one instead.");
                        CreateNewSaveFile();
                    }
                    else
                    {
                        Console.WriteLine("\nAvailable Save Files:");
                        for (int i = 0; i < saveFiles.Count; i++)
                        {
                            Console.WriteLine($"{i + 1}. {saveFiles[i]}");
                        }

                        Console.Write("Enter the number of the save file to load (or 0 to go back): ");
                        if (int.TryParse(Console.ReadLine(), out int fileIndex))
                        {
                            if (fileIndex == 0)
                            {
                                continue;  // Goes back to the save selection screen
                            }
                            else if (fileIndex > 0 && fileIndex <= saveFiles.Count)
                            {
                                string selectedSave = saveFiles[fileIndex - 1];
                                RecordKeeper.SetSaveFile(selectedSave);
                                RecordKeeper.LoadRecords();
                                Console.WriteLine($"Loaded save file: {selectedSave}");
                                break; // Exit loop and proceed to the main menu
                            }
                        }
                        Console.WriteLine("Invalid choice. Returning to save selection screen...");
                    }
                }
                else if (choice == "3") // Return to Main Menu
                {
                    Console.WriteLine("Returning to Main Menu...");
                    return;  // Exits the function and returns to the main menu
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 1, 2, or 3.");
                }
            }
        }

        static void CreateNewSaveFile()
        {
            Console.Write("Enter a name for your new save file: ");
            string saveName = Console.ReadLine().Trim();

            if (string.IsNullOrWhiteSpace(saveName))
            {
                Console.WriteLine("Invalid name. Using default save name.");
                saveName = "default";
            }

            RecordKeeper.SetSaveFile(saveName);
            RecordKeeper.SaveRecords();
            Console.WriteLine($"New save file created: {saveName}");
        }
    }
}

