﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectTwo;


namespace ProjectTwo
{
    public abstract class Game
    {
        protected Deck deck;
        protected int score;
        protected bool quitEarly;
        protected const int TotalRounds = 10;

        public abstract void PlayGame();

        protected void EndGame(string gameName)
        {
            Console.WriteLine($"Game Over! Final score: {score} (out of {TotalRounds} rounds)");

            if (quitEarly)
            {
                Console.WriteLine("Session ended early. This attempt will not be recorded.");
            }
            else
            {
                if (score >= RecordKeeper.GuessWinThreshold)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("You Win!");
                    RecordWin(gameName);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You Lose.");
                    RecordLoss(gameName);
                }
            }

            Console.ResetColor();
            Console.WriteLine("Press any key to return to the main menu...");
            Console.ReadKey();
        }

        protected void RecordWin(string gameName)
        {
            if (gameName == "Apples or Oranges") RecordKeeper.ApplesWins++;
            if (gameName == "Higher or Lower") RecordKeeper.HigherWins++;
            if (gameName == "Highest Match") RecordKeeper.MatchWins++;
        }

        protected void RecordLoss(string gameName)
        {
            if (gameName == "Apples or Oranges") RecordKeeper.ApplesLosses++;
            if (gameName == "Higher or Lower") RecordKeeper.HigherLosses++;
            if (gameName == "Highest Match") RecordKeeper.MatchLosses++;
        }
    }
    public class GameLogic : IGame
    {
        public void PlayGame(string gameName)
        {
            Game game;
            switch (gameName)
            {
                case "Apples or Oranges":
                    game = new ApplesOrOranges();
                    break;
                case "Higher or Lower":
                    game = new HigherOrLower();
                    break;
                case "Highest Match":
                    game = new HighestMatch();
                    break;
                default:
                    Console.WriteLine("Unknown game.");
                    return;
            }

            game.PlayGame();
        }
    }
    public class ApplesOrOranges : Game
    {
        public override void PlayGame()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.WriteLine("🍏🍊 Welcome to Apples or Oranges! 🍏🍊");
            Console.WriteLine("Description: In this game, you'll see a card drawn from a half deck (only 2 suits).");
            Console.WriteLine("Your task is to guess whether the next card will have the SAME suit or a DIFFERENT suit.");
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();
            Console.Clear();

            deck = new Deck(2);
            score = 0;
            quitEarly = false;
            Card previousCard = deck.DrawCard();

            for (int round = 1; round <= TotalRounds; round++)
            {
                Console.WriteLine($"Round {round}/{TotalRounds}");
                Console.WriteLine($"Current Card: {previousCard}");
                Console.Write("Your guess - Same suit or Different? (S/D): ");
                string guess = Console.ReadLine().ToUpper();

                Card nextCard = deck.DrawCard();
                if (nextCard == null)
                {
                    Console.WriteLine("No more cards in the deck.");
                    break;
                }

                bool isSameSuit = previousCard.Suit == nextCard.Suit;
                bool correct = (guess == "S" && isSameSuit) || (guess == "D" && !isSameSuit);
                string resultMessage = correct ? "Correct!" : "Wrong!";
                Console.ForegroundColor = correct ? ConsoleColor.Green : ConsoleColor.Red;
                Console.WriteLine($"Next Card: {nextCard} → {resultMessage}");
                Console.ForegroundColor = ConsoleColor.Black;

                if (correct) score++;

                previousCard = nextCard;
                Console.WriteLine($"Score so far: {score}\n");

                if (round < TotalRounds)
                {
                    Console.Write("Press Enter to continue to the next round or Q to quit early: ");
                    string input = Console.ReadLine().ToUpper();
                    if (input == "Q")
                    {
                        quitEarly = true;
                        break;
                    }
                }
                Console.Clear();
            }

            EndGame("Apples or Oranges");
        }
    }
    public class HigherOrLower : Game
    {
        public override void PlayGame()
        {
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.WriteLine("⬆ Higher or Lower ⬇");
            Console.WriteLine("Description: In this game, you'll guess whether the next card's value will be higher or lower than the current card.");
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();
            Console.Clear();

            deck = new Deck();
            score = 0;
            quitEarly = false;
            Card previousCard = deck.DrawCard();

            for (int round = 1; round <= TotalRounds; round++)
            {
                Console.Clear();
                Console.WriteLine($"Round {round}/{TotalRounds}");
                Console.WriteLine($"Current Card: {previousCard}");
                Console.Write("Your guess - Higher or Lower? (H/L): ");
                string guess = Console.ReadLine().ToUpper();

                Card nextCard = deck.DrawCard();
                if (nextCard == null)
                {
                    Console.WriteLine("No more cards in the deck.");
                    break;
                }

                bool correct = false;
                if (nextCard.Value == previousCard.Value)
                {
                    Console.WriteLine($"Next Card: {nextCard} → It's a tie! No point awarded.");
                }
                else
                {
                    correct = (guess == "H" && nextCard.Value > previousCard.Value) ||
                              (guess == "L" && nextCard.Value < previousCard.Value);

                    string resultMessage = correct ? "Correct!" : "Wrong!";
                    Console.ForegroundColor = correct ? ConsoleColor.Green : ConsoleColor.Red;
                    Console.WriteLine($"Next Card: {nextCard} → {resultMessage}");
                    Console.ForegroundColor = ConsoleColor.Black;

                    if (correct) score++;
                }

                previousCard = nextCard;
                Console.WriteLine($"Score so far: {score}\n");

                if (round < TotalRounds)
                {
                    Console.Write("Press Enter to continue to the next round or Q to quit early: ");
                    string input = Console.ReadLine().ToUpper();
                    if (input == "Q")
                    {
                        quitEarly = true;
                        break;
                    }
                }
                Console.Clear();
            }

            EndGame("Higher or Lower");
        }
    }
    public class HighestMatch : Game
    {
        public override void PlayGame()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.WriteLine("🎴 Highest Match Game 🎴");
            Console.WriteLine("Description: In this game, you and the dealer each receive 10 cards.");
            Console.WriteLine("Your objective is to have the highest total value for cards of a single suit.");
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();
            Console.Clear();

            deck = new Deck();
            score = 0;
            quitEarly = false;
            List<Card> playerCards = new List<Card>();

            for (int round = 1; round <= TotalRounds; round++)
            {
                Console.Clear();
                Card drawn = deck.DrawCard();
                if (drawn == null)
                    break;
                playerCards.Add(drawn);
                Console.WriteLine($"Round {round}/{TotalRounds}: You drew {drawn}");
                if (round < TotalRounds)
                {
                    Console.Write("Press Enter to continue to the next round or Q to quit early: ");
                    string input = Console.ReadLine().ToUpper();
                    if (input == "Q")
                    {
                        quitEarly = true;
                        break;
                    }
                }
                Console.Clear();
            }

            if (quitEarly || playerCards.Count < TotalRounds)
            {
                Console.WriteLine("Session ended early. This attempt will not be recorded.");
                return;
            }

            List<Card> dealerCards = new List<Card>();
            for (int i = 0; i < TotalRounds; i++)
            {
                Card drawn = deck.DrawCard();
                dealerCards.Add(drawn);
            }

            int playerScore = GetBestSuitScore(playerCards);
            int dealerScore = GetBestSuitScore(dealerCards);

            Console.WriteLine("Your Cards:");
            foreach (Card card in playerCards)
                Console.Write(card + " ");
            Console.WriteLine("\n");

            Console.WriteLine("Dealer's Cards:");
            foreach (Card card in dealerCards)
                Console.Write(card + " ");
            Console.WriteLine("\n");
            Console.WriteLine($"Your Best Suit Score: {playerScore}");
            Console.WriteLine($"Dealer's Best Suit Score: {dealerScore}\n");
            Console.ForegroundColor = playerScore > dealerScore ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine(playerScore > dealerScore ? "Congratulations, You Win!" : "Sorry, You Lose!");
            Console.ResetColor();
            Console.WriteLine("\nPress any key to return to the main menu...");
            Console.ReadKey();
        }

        private static int GetBestSuitScore(List<Card> cards)
        {
            return cards.GroupBy(c => c.Suit)
                        .Select(group => group.Sum(c => c.Value))
                        .Max();
        }
    }

}



