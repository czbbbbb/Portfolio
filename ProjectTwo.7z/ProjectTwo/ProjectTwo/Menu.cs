﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTwo
{
        class Menu
        {
            public void ShowMainMenu()
            {
                Console.Clear();
                Console.WriteLine("======================================");
                Console.WriteLine("        🎲 Card Game Collection 🎲       ");
                Console.WriteLine("======================================");
                Console.WriteLine("1. Play");
                Console.WriteLine("2. View Records");
                Console.WriteLine("3. Exit");
                Console.Write("Choose an option (1-3): ");
            }

            public string GetUserChoice()
            {
                return Console.ReadLine();
            }

            public IGame GetGame(string choice)
            {
                return choice switch
                {
                    "1" => new GameLogic(),
                    _ => null
                };
            }
        }
}