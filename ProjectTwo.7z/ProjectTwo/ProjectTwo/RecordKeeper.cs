﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace ProjectTwo
{
    static class RecordKeeper
    {
        public static int ApplesWins { get; set; }
        public static int ApplesLosses { get; set; }
        public static int HigherWins { get; set; }
        public static int HigherLosses { get; set; }
        public static int MatchWins { get; set; }
        public static int MatchLosses { get; set; }
        public static int HighestMatchWins { get; set; }
        public static int HighestMatchLosses { get; set; }
        public static int GuessWinThreshold { get; set; } = 7;

        private static string saveDirectory = "Saves";
        private static string currentSaveFile = "default.json";

        public static void SetSaveFile(string saveFileName)
        {
            currentSaveFile = $"{saveFileName}.json";
        }

        public static List<string> GetSaveFiles() //Show available save files
        {
            if (!Directory.Exists(saveDirectory))
                return new List<string>();

            string[] files = Directory.GetFiles(saveDirectory, "*.json");
            List<string> saveFiles = new List<string>();

            foreach (string file in files)
            {
                saveFiles.Add(Path.GetFileNameWithoutExtension(file)); 
            }

            return saveFiles;
        }

        public static void LoadRecords() //Load game records from a file
        {
            string filePath = Path.Combine(saveDirectory, currentSaveFile);

            if (File.Exists(filePath))
            {
                try
                {
                    string json = File.ReadAllText(filePath);
                    var data = JsonSerializer.Deserialize<dynamic>(json);

                    ApplesWins = data.GetProperty("ApplesWins").GetInt32();
                    ApplesLosses = data.GetProperty("ApplesLosses").GetInt32();
                    HigherWins = data.GetProperty("HigherWins").GetInt32();
                    HigherLosses = data.GetProperty("HigherLosses").GetInt32();
                    MatchWins = data.GetProperty("MatchWins").GetInt32();
                    MatchLosses = data.GetProperty("MatchLosses").GetInt32();
                    HighestMatchWins = data.GetProperty("HighestMatchWins").GetInt32();
                    HighestMatchLosses = data.GetProperty("HighestMatchLosses").GetInt32();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading records: {ex.Message}");
                }
            }
        }

        public static void SaveRecords() //Save record to the current save file
        {
            try
            {
                if (!Directory.Exists(saveDirectory))
                    Directory.CreateDirectory(saveDirectory);

                string filePath = Path.Combine(saveDirectory, currentSaveFile);

                var data = new
                {
                    ApplesWins,
                    ApplesLosses,
                    HigherWins,
                    HigherLosses,
                    MatchWins,
                    MatchLosses,
                    HighestMatchWins,
                    HighestMatchLosses
                };

                string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving records: {ex.Message}");
            }
        }
        public static void ShowRecords()
        {
            Console.Clear();
            Console.WriteLine("========== Records ==========");
            Console.WriteLine("Apples or Oranges:");
            Console.WriteLine($"  Wins:   {ApplesWins}");
            Console.WriteLine($"  Losses: {ApplesLosses}");
            Console.WriteLine("\nHigher or Lower:");
            Console.WriteLine($"  Wins:   {HigherWins}");
            Console.WriteLine($"  Losses: {HigherLosses}");
            Console.WriteLine("\nHighest Match:");
            Console.WriteLine($"  Wins:   {HighestMatchWins}");
            Console.WriteLine($"  Losses: {HighestMatchLosses}");
            Console.WriteLine("=============================");
            Console.WriteLine("Press any key to return to the main menu...");
            Console.ReadKey();
        }
    }
}

