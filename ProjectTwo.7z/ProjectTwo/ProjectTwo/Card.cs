﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTwo
{
    public class Card
    {
        public string Suit { get; }
        public int Value { get; }

        private static readonly string[] Suits = { "♥", "♦", "♣", "♠" };
        private static readonly string[] ValueNames = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };

        public Card(int value, int suit)
        {
            Value = value;
            Suit = Suits[suit];
        }

        public override string ToString()
        {
            return $"{ValueNames[Value - 2]}{Suit}";
        }
    }
}
